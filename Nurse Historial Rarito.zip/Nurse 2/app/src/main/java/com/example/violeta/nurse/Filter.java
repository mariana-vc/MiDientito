package com.example.violeta.nurse;

/**
 * Created by velahuer on 03/04/16.
 */
public interface Filter {
    public void execute(String request);
}
