package com.example.violeta.nurse;


public class Hist {
    public String nombre, descripcion;

    public Hist(String nombre, String descripcion){
        this.descripcion=descripcion;
        this.nombre=nombre;
    }
    public Hist(){

    }

}
